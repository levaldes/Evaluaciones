/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package instituto;

/**
 *
 * @author Leonardo
 */
public class Sede {
    private int nroSede;
    private String nombre;
    private String comuna;

    public Sede(int nroSede, String nombre, String comuna) {
        this.nroSede = nroSede;
        this.nombre = nombre;
        this.comuna = comuna;
    }

    public int getNroSede() { return nroSede; }
    public void setNroSede(int nroSede) { this.nroSede = nroSede; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getComuna() { return comuna; }
    public void setComuna(String comuna) { this.comuna = comuna; }
}

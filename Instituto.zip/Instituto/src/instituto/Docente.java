/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package instituto;

/**
 *
 * @author Leonardo
 */

import java.time.LocalDate;

public class Docente {
    private String rut;
    private int nroDocente;
    private String nombre;
    private LocalDate fechaIngreso;
    private String sede;

    public Docente(String rut, int nroDocente, String nombre, LocalDate fechaIngreso, String sede) {
        if(nombre == null || nombre.isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío.");
        }
        if(fechaIngreso.isAfter(LocalDate.now())) {
            throw new IllegalArgumentException("La fecha de ingreso no puede ser posterior a hoy.");
        }
        this.rut = rut;
        this.nroDocente = nroDocente;
        this.nombre = nombre;
        this.fechaIngreso = fechaIngreso;
        this.sede = sede;
    }

    public String getRut() { return rut; }
    public void setRut(String rut) { this.rut = rut; }

    public int getNroDocente() { return nroDocente; }
    public void setNroDocente(int nroDocente) { this.nroDocente = nroDocente; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) {
        if(nombre == null || nombre.isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío.");
        }
        this.nombre = nombre;
    }

    public LocalDate getFechaIngreso() { return fechaIngreso; }
    public void setFechaIngreso(LocalDate fechaIngreso) {
        if(fechaIngreso.isAfter(LocalDate.now())) {
            throw new IllegalArgumentException("La fecha de ingreso no puede ser posterior a hoy.");
        }
        this.fechaIngreso = fechaIngreso;
    }

    public String getSede() { return sede; }
    public void setSede(String sede) { this.sede = sede; }
}

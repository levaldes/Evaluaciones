/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package instituto;

/**
 *
 * @author Leonardo
 */


import java.util.Scanner;
import java.time.LocalDate;
public class Instituto {

    /**
     * @param args the command line arguments
     */
        public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Estudiante estudiante = null;
        Docente docente = null;
        Asignatura asignatura = null;

        int opcion;
        do {
            System.out.println("=== SISTEMA DE REGISTRO DE ASIGNATURAS ===");
            System.out.println("1. Ingresar Estudiante");
            System.out.println("2. Ingresar Docente");
            System.out.println("3. Ingresar Asignatura");
            System.out.println("4. Calcular Resultados");
            System.out.println("5. Mostrar Notas");
            System.out.println("6. Buscar Estudiante");
            System.out.println("7. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = sc.nextInt();
            sc.nextLine();

            switch(opcion) {
                case 1:
                    System.out.print("Ingrese RUT: ");
                    String rutE = sc.nextLine();
                    System.out.print("Ingrese nombre: ");
                    String nombreE = sc.nextLine();
                    System.out.print("Ingrese edad: ");
                    int edad = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Ingrese fecha nacimiento (AAAA-MM-DD): ");
                    LocalDate fechaN = LocalDate.parse(sc.nextLine());
                    estudiante = new Estudiante(rutE, nombreE, edad, fechaN);
                    System.out.println("Estudiante registrado con éxito.");
                    break;

                case 2:
                    System.out.print("Ingrese RUT docente: ");
                    String rutD = sc.nextLine();
                    System.out.print("Ingrese número de docente: ");
                    int nroDoc = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Ingrese nombre docente: ");
                    String nombreD = sc.nextLine();
                    System.out.print("Ingrese fecha ingreso (AAAA-MM-DD): ");
                    LocalDate fechaI = LocalDate.parse(sc.nextLine());
                    System.out.print("Ingrese sede: ");
                    String sede = sc.nextLine();
                    docente = new Docente(rutD, nroDoc, nombreD, fechaI, sede);
                    System.out.println("Docente registrado con éxito.");
                    break;

                case 3:
                    if(estudiante == null || docente == null) {
                        System.out.println("Debe ingresar estudiante y docente antes.");
                    } else {
                        System.out.print("Ingrese código asignatura: ");
                        String codigo = sc.nextLine();
                        System.out.print("Ingrese nombre asignatura: ");
                        String nombreA = sc.nextLine();
                        System.out.print("Ingrese nota1: ");
                        double n1 = sc.nextDouble();
                        System.out.print("Ingrese nota2: ");
                        double n2 = sc.nextDouble();
                        System.out.print("Ingrese nota3: ");
                        double n3 = sc.nextDouble();
                        asignatura = new Asignatura(codigo, nombreA, estudiante, docente, n1, n2, n3);
                        System.out.println("Asignatura registrada con éxito.");
                    }
                    break;

                case 4:
                    if(asignatura != null) {
                        double np = asignatura.calcularNotaPresentacion();
                        System.out.println("Nota de presentación: " + np);
                        if(asignatura.verificarEximicion()) {
                            System.out.println("El estudiante está EXIMIDO.");
                        } else {
                            System.out.print("Ingrese nota de examen: ");
                            double examen = sc.nextDouble();
                            System.out.println(asignatura.calcularNotaFinal(examen));
                        }
                    } else {
                        System.out.println("Debe ingresar una asignatura primero.");
                    }
                    break;

                case 5:
                    if(asignatura != null) {
                        System.out.println("Notas: " + asignatura.getNota1() + ", " +
                                           asignatura.getNota2() + ", " + asignatura.getNota3());
                    } else {
                        System.out.println("No hay asignaturas registradas.");
                    }
                    break;

                case 6:
                    if(estudiante != null) {
                        System.out.println("Estudiante: " + estudiante.getNombre() +
                                           " - RUT: " + estudiante.getRut());
                    } else {
                        System.out.println("No hay estudiantes registrados.");
                    }
                    break;

                case 7:
                    System.out.println("Saliendo del sistema...");
                    break;
            }
            System.out.println();
        } while(opcion != 7);

        sc.close();
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package instituto;

/**
 *
 * @author Leonardo
 */
import java.time.LocalDate;

public class Estudiante {
    private String rut;
    private String nombre;
    private int edad;
    private LocalDate fechaNacimiento;

    public Estudiante(String rut, String nombre, int edad, LocalDate fechaNacimiento) {
        if(nombre == null || nombre.isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío.");
        }
        if(edad < 18 || edad >= 100) {
            throw new IllegalArgumentException("La edad debe ser >=18 y <100.");
        }
        this.rut = rut;
        this.nombre = nombre;
        this.edad = edad;
        this.fechaNacimiento = fechaNacimiento;
    }
    
    public String getRut() { return rut; }
    public void setRut(String rut) { this.rut = rut; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) {
        if(nombre == null || nombre.isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío.");
        }
        this.nombre = nombre;
    }

    public int getEdad() { return edad; }
    public void setEdad(int edad) {
        if(edad < 18 || edad >= 100) {
            throw new IllegalArgumentException("La edad debe ser >=18 y <100.");
        }
        this.edad = edad;
    }

    public LocalDate getFechaNacimiento() { return fechaNacimiento; }
    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }
}


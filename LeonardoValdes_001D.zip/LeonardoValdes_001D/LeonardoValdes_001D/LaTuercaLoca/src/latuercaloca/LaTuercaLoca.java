/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package latuercaloca;

/**
 *
 * @author Leonardo
 */
import java.util.Scanner;

public class LaTuercaLoca {
    public static void main(String[] args) {
        Concesionaria concesionaria = new Concesionaria();
        Scanner sc = new Scanner(System.in);
        boolean salir = false;

        while (!salir) {
            System.out.println("La tuerca loca_");
            System.out.println("1. Ingresar vehiculo");
            System.out.println("2. Mostrar informacion ");
            System.out.println("3. Aplicar ajuste precio");
            System.out.println("4. Aplicar impuesto");
            System.out.println("5. Salir");
            System.out.print("Escoja opcion: ");
            String opcion = sc.nextLine().trim();

            switch (opcion) {
                case "1":
                    System.out.print("Tipo (A = Auto, M = Moto): ");
                    String tipo = sc.nextLine().trim().toUpperCase();
                    if (tipo.equals("A")) {
                        System.out.print("Codigo: "); String codigoA = sc.nextLine().trim();
                        System.out.print("Marca: "); String marcaA = sc.nextLine().trim();
                        System.out.print("Modelo: "); String modeloA = sc.nextLine().trim();
                        System.out.print("Precio base: "); double precioA = Double.parseDouble(sc.nextLine().trim());
                        System.out.print("Anio fabricacion: "); int anioA = Integer.parseInt(sc.nextLine().trim());
                        System.out.print("Tipo carroceria (sedan/SUV): "); String carro = sc.nextLine().trim();
                        System.out.print("Cantidad puertas: "); int puertas = Integer.parseInt(sc.nextLine().trim());

                        Automovil auto = new Automovil(codigoA, marcaA, modeloA, precioA, anioA, carro, puertas);
                        if (concesionaria.ingresarVehiculo(auto)) {
                            System.out.println("Automovil ingresado correctamente");
                        } else {
                            System.out.println("Ya existe un vehículo con ese codigo");
                        }
                    } else if (tipo.equals("M")) {
                        System.out.print("Codigo: "); String codigoM = sc.nextLine().trim();
                        System.out.print("Marca: "); String marcaM = sc.nextLine().trim();
                        System.out.print("Modelo: "); String modeloM = sc.nextLine().trim();
                        System.out.print("Precio base: "); double precioM = Double.parseDouble(sc.nextLine().trim());
                        System.out.print("Anno fabricacion: "); int anioM = Integer.parseInt(sc.nextLine().trim());
                        System.out.print("Tipo (deportiva/clasica): "); String tipoMoto = sc.nextLine().trim();
                        System.out.print("Cilindrada: "); int cilindrada = Integer.parseInt(sc.nextLine().trim());

                        Motocicleta moto = new Motocicleta(codigoM, marcaM, modeloM, precioM, anioM, tipoMoto, cilindrada);
                        if (concesionaria.ingresarVehiculo(moto)) {
                            System.out.println("Motocicleta ingresada correctamente");
                        } else {
                            System.out.println("Ya existe un vehículo con ese codigo");
                        }
                    } else {
                        System.out.println("Opcion no valida.");
                    }
                    break;

                case "2":
                    System.out.print("Ingrese codigo del vehículo: ");
                    String codBuscar = sc.nextLine().trim();
                    Vehiculo encontrado = concesionaria.buscarVehiculo(codBuscar);
                    if (encontrado != null) {
                        System.out.println("Informacion del vehículo");
                        System.out.println(encontrado.toString());
                    } else {
                        System.out.println("No se encontro vehiculo con ese codigo.");
                    }
                    break;

                case "3":
                    int totalAjustados = concesionaria.aplicarAjusteATodos();
                    System.out.println("Ajuste aplicado. Total de vehiculos ajustados: " + totalAjustados);
                    break;

                case "4":
                    double totalDescuento = concesionaria.calcularDescuentoTotal();
                    System.out.println("Total ahorro por descuentos (descuentoFeriado): " + String.format("", totalDescuento));
                    break;

                case "5":
                    salir = true;
                    System.out.println("Saliste del programa");
                    break;

                default:
                    System.out.println("Opcion no valida intente denuevo");
            }
        }
        sc.close();
    }
}
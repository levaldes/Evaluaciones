/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package latuercaloca;

public class Motocicleta extends Vehiculo {
    private String tipo;
    private int cilindrada;

    public Motocicleta(String codigo, String marca, String modelo, double precioBase, int anioFabricacion,
                       String tipo, int cilindrada) {
        super(codigo, marca, modelo, precioBase, anioFabricacion);
        this.tipo = tipo;
        this.cilindrada = cilindrada;
    }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public int getCilindrada() { return cilindrada; }
    public void setCilindrada(int cilindrada) { this.cilindrada = cilindrada; }

    @Override
    public boolean ajustePrecio() {
        if (tipo != null && tipo.equalsIgnoreCase("clásica")) {
            precioBase = precioBase * 0.85;
            return true;
        }
        return false;
    }

    @Override
    public boolean aplicarImpuesto() {
        if (cilindrada > 600) {
            precioBase = precioBase + (precioBase * IMPUESTO_PORC);
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return "Motocicleta\n" + super.toString() +
               "\nTipo: " + tipo +
               "\nCilindrada: " + cilindrada + " cc";
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package latuercaloca;

import java.util.ArrayList;

public class Concesionaria {
    private ArrayList<Vehiculo> vehiculos;

    public Concesionaria() {
        vehiculos = new ArrayList<>();
    }

    public boolean ingresarVehiculo(Vehiculo v) {
        if (buscarVehiculo(v.getCodigo()) != null) {
            return false;
        }
        vehiculos.add(v);
        return true;
    }

    public Vehiculo buscarVehiculo(String codigo) {
        for (Vehiculo v : vehiculos) {
            if (v.getCodigo().equalsIgnoreCase(codigo)) {
                return v;
            }
        }
        return null;
    }

    public int aplicarAjusteATodos() {
        int contador = 0;
        for (Vehiculo v : vehiculos) {
            if (v.ajustePrecio()) contador++;
        }
        return contador;
    }

    public double calcularDescuentoTotal() {
        double total = 0.0;
        for (Vehiculo v : vehiculos) {
            if (v instanceof PromEspecial) {
                PromEspecial pe = (PromEspecial) v;
                total += pe.descuentoFeriado();
            }
        }
        return total;
    }

    public ArrayList<Vehiculo> getVehiculos() { return vehiculos; }
}

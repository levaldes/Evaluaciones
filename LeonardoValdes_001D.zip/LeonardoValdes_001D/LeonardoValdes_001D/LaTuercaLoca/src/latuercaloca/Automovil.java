package latuercaloca;

public class Automovil extends Vehiculo implements PromEspecial {
    private String tipoCarroceria;
    private int cantidadPuertas;

    public Automovil(String codigo, String marca, String modelo, double precioBase, int anioFabricacion,
                     String tipoCarroceria, int cantidadPuertas) {
        super(codigo, marca, modelo, precioBase, anioFabricacion);
        this.tipoCarroceria = tipoCarroceria;
        this.cantidadPuertas = cantidadPuertas;
    }

    public String getTipoCarroceria() { return tipoCarroceria; }
    public void setTipoCarroceria(String tipoCarroceria) { this.tipoCarroceria = tipoCarroceria; }

    public int getCantidadPuertas() { return cantidadPuertas; }
    public void setCantidadPuertas(int cantidadPuertas) { this.cantidadPuertas = cantidadPuertas; }

    @Override
    public boolean ajustePrecio() {
        return false;
    }

    @Override
    public boolean aplicarImpuesto() {
        if (tipoCarroceria != null && tipoCarroceria.equalsIgnoreCase("SUV")) {
            precioBase = precioBase + (precioBase * IMPUESTO_PORC);
            return true;
        }
        return false;
    }

    @Override
    public double descuentoFeriado() {
        if (marca != null && marca.equalsIgnoreCase("Ford") &&
            tipoCarroceria != null && tipoCarroceria.equalsIgnoreCase("SUV")) {
            return precioBase * DTO;
        }
        return 0.0;
    }

    @Override
    public String toString() {
        return "Automóvil\n" + super.toString() +
               "\nTipo carrocería: " + tipoCarroceria +
               "\nCantidad puertas: " + cantidadPuertas;
    }
}
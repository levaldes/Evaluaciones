
package latuercaloca;

/**
 *
 * @author Leonardo
 */
public interface PromEspecial {
    public double DTO = 0.123;
    public  double descuentoFeriado();
}
